<?php
/**
 * Plugin Name: Contentman AI Sharing Button
 * Description: Share- und Zusammenfassen-Buttons für ChatGPT, Perplexity, Grok, Claude und WhatsApp.
 * Version: 0.9
 * Author: contentman.de
 */

add_action('wp_head', 'ai_share_buttons_styles');
add_filter('the_content', 'multi_share_buttons');
add_shortcode('ai_share', 'ai_share_buttons_shortcode');

/**
 * Fügt Styles für Buttons ein.
 */
function ai_share_buttons_styles() {
    echo '<style>
    .ai-share-buttons {
        background: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 20px;
        margin: 25px 0;
        border-left: 4px solid #6f42c1;
        position: relative;
    }
    .ai-share-buttons::before {
        content: "🤖 Artikel von deiner KI zusammenfassen lassen";
        display: block;
        font-weight: 600;
        color: #6f42c1;
        margin-bottom: 15px;
        font-size: 14px;
    }
    .ai-share-buttons .buttons { 
        display: flex; 
        flex-wrap: wrap; 
        gap: 12px; 
    }
    .ai-share-buttons .buttons a {
        display: inline-flex; 
        align-items: center;
        padding: 10px 12px;
        border-radius: 6px;
        text-decoration: none;
        transition: all 0.3s ease;
        background: #fff;
        border: 1px solid #dee2e6;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .ai-share-buttons .buttons a:hover { 
        background-color: #f8f9fa;
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        text-decoration: none;
    }
    .ai-icon { 
        width: 20px; 
        height: 20px; 
    }
    @media (max-width: 600px) {
        .ai-share-buttons .buttons {
            justify-content: center;
        }
        .ai-share-buttons .buttons a {
            padding: 8px 10px;
        }
        .ai-icon {
            width: 18px;
            height: 18px;
        }
    }
    </style>';
}

/**
 * Liefert SVG-Icons für die verschiedenen Services.
 */
function get_service_icon($service) {
    $icons = [
        'chatgpt' => '<svg viewBox="0 0 24 24" class="ai-icon"><path fill="#10a37f" d="M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.364 15.1192 7.2a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.4997-2.6067-1.4997Z"/></svg>',
        
        'perplexity' => '<svg viewBox="0 0 24 24" class="ai-icon"><path fill="#20808d" d="M12.14 0C5.434 0 .014 5.42.014 12.126S5.434 24.252 12.14 24.252s12.126-5.42 12.126-12.126S18.846 0 12.14 0zm0 22.389c-5.66 0-10.263-4.603-10.263-10.263S6.48 1.863 12.14 1.863s10.263 4.603 10.263 10.263-4.603 10.263-10.263 10.263z"/><path fill="#20808d" d="M12.14 4.897c-3.993 0-7.229 3.236-7.229 7.229s3.236 7.229 7.229 7.229 7.229-3.236 7.229-7.229-3.236-7.229-7.229-7.229zm0 12.595c-2.96 0-5.366-2.406-5.366-5.366s2.406-5.366 5.366-5.366 5.366 2.406 5.366 5.366-2.406 5.366-5.366 5.366z"/><circle fill="#20808d" cx="12.14" cy="12.126" r="2.683"/></svg>',
        
        'grok' => '<svg viewBox="0 0 24 24" class="ai-icon"><path fill="#1da1f2" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
        
        'claude' => '<svg viewBox="0 0 24 24" class="ai-icon"><path fill="#cc785c" d="M16.77 2.286C13.357.095 8.643-.095 5.23 2.286 1.816 4.476.064 8.619.064 12.762c0 4.143 1.752 8.286 5.166 10.476 3.413 2.191 8.127 2.381 11.54 0 3.414-2.19 5.166-6.333 5.166-10.476 0-4.143-1.752-8.286-5.166-10.476zm-4.008 17.428c-2.857 0-5.714-1.238-7.714-3.238-2-2-3.238-4.857-3.238-7.714s1.238-5.714 3.238-7.714c2-2 4.857-3.238 7.714-3.238s5.714 1.238 7.714 3.238c2 2 3.238 4.857 3.238 7.714s-1.238 5.714-3.238 7.714c-2 2-4.857 3.238-7.714 3.238z"/></svg>',
        
        'whatsapp' => '<svg viewBox="0 0 24 24" class="ai-icon"><path fill="#25d366" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.064 3.488"/></svg>'
    ];
    
    return $icons[$service] ?? '';
}

/**
 * Baut den Button-HTML-Block.
 */
function build_buttons_html() {
    $post_url    = get_permalink();
    $post_title  = get_the_title();
    
    $chatgpt_url    = 'https://chat.openai.com/?q=' . urlencode("Besuche diese URL und fasse mir diesen Beitrag zusammen: " . $post_url);
    $perplexity_url = 'https://www.perplexity.ai/search/new?q=' . urlencode("Besuche diese URL und fasse den Beitrag für mich zusammen: " . $post_url);
    $grok_url       = 'https://x.com/i/grok?text=' . urlencode("Fasse diese URL zusammen: {$post_url}");
    $claude_url     = 'https://claude.ai/new?q=' . urlencode("Fasse diesen Beitrag für mich zusammen: {$post_url}");
    $whatsapp_url   = 'https://wa.me/?text=' . urlencode("{$post_title} - {$post_url}");
    
    // Icons als Variablen speichern
    $chatgpt_icon = get_service_icon('chatgpt');
    $perplexity_icon = get_service_icon('perplexity');
    $grok_icon = get_service_icon('grok');
    $claude_icon = get_service_icon('claude');
    $whatsapp_icon = get_service_icon('whatsapp');
    
    return <<<HTML
<div class="ai-share-buttons">
  <div class="buttons">
    <a href="$chatgpt_url"    target="_blank" title="ChatGPT öffnen">
      $chatgpt_icon
    </a>
    <a href="$perplexity_url" target="_blank" title="Perplexity öffnen">
      $perplexity_icon
    </a>
    <a href="$grok_url"       target="_blank" title="Grok öffnen">
      $grok_icon
    </a>
    <a href="$claude_url"     target="_blank" title="Claude öffnen">
      $claude_icon
    </a>
    <a href="$whatsapp_url"   target="_blank" title="WhatsApp teilen">
      $whatsapp_icon
    </a>
  </div>
</div>
HTML;
}

/**
 * Filter-Funktion für automatisches Einfügen im Content.
 */
function multi_share_buttons($content) {
    if (is_single() && in_the_loop() && is_main_query()) {
        // Sharing Buttons ganz oben platzieren
        return build_buttons_html() . $content;
    }
    return $content;
}

/**
 * Shortcode-Funktion.
 * Liefert via return den HTML-Block für [ai_share].
 */
function ai_share_buttons_shortcode($atts = [], $content = null) {
    return build_buttons_html();
}